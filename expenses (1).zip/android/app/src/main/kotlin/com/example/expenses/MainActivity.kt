package com.example.expenses

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
